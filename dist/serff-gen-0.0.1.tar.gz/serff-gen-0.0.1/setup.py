from setuptools import setup, find_packages

VERSION = '0.0.1' 
DESCRIPTION = 'SERFF generator prototype'
LONG_DESCRIPTION = 'SERFF generator prototype'

# Setting up
setup(
        name="serff-gen", 
        version=VERSION,
        author="ECV Peeps",
        author_email="ecv_devph@ecloudvalley.com",
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        packages=find_packages(),
        install_requires=[], # add any additional packages that 
        # needs to be installed along with your package. Eg: 'caer'
        py_modules=['main'],
        keywords=['python', 'serff', 'ecv-code-generator'],
        classifiers= [
            "Development Status :: Alpha",
            "Intended Audience :: Education",
            "Programming Language :: Python :: 3",
            "Operating System :: MacOS :: MacOS X",
            "Operating System :: Microsoft :: Windows",
        ],
        entry_points={
            'console_scripts': [
                'serff = main:run_parser'
            ]
        }
)