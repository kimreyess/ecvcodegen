#messages directory
DESCRIPTION = "PySERFF CLI, for creating microservices using Serverless Framework for your application."
BANNER = f"""\
    {DESCRIPTION}
    Use -h or --help to see commands available.
"""
                                    